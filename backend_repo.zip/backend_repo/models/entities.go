package models

type Kind = string
