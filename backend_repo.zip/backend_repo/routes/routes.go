package routes

import (
	"context"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"go.mongodb.org/mongo-driver/mongo"
	"profit/repository/use_cases/dbs_repositories/mongoDriver"
	"profit/routes/auth/protection"
	"profit/routes/handlers"
)

func InitRoutes(db *mongo.Database, ctx context.Context) *chi.Mux {
	r := chi.NewRouter()

	// Middleware
	r.Use(middleware.Logger)
	r.Use(middleware.Recoverer)

	// Инициализация хендлеров
	adminRepo := mongoDriver.NewAdminMongoRepository(db, ctx)

	adminHandler := handlers.NewAdminCaseController(adminRepo)
	// Открытые маршруты
	r.Post("/api/login", adminHandler.LoginHandler)
	r.Post("/api/register", adminHandler.RegisterHandler)

	// Защищенные маршруты
	r.Group(func(protected chi.Router) {
		protected.Use(protection.RoleMiddleware("admin"))

		//protected.Get("/api/profile", adminHandler.GetProfile)
	})

	return r
}
